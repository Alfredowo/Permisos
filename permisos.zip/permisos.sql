CREATE DATABASE permisos;
USE permisos;

DROP TABLE productos;
CREATE TABLE productos(
codigoBarras INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL,
descripcion VARCHAR(100) NOT NULL,
marca VARCHAR(50) NOT NULL);

DROP TABLE herramientas;
CREATE TABLE herramientas(
codigoHerramienta INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL,
descripcion VARCHAR(100) NOT NULL,
marca VARCHAR(50) NOT NULL,
medida INT NOT NULL);

DROP TABLE usuarios;
CREATE TABLE usuarios(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL, 
apellidop VARCHAR(50) NOT NULL,
apellidom VARCHAR(50) NOT NULL,
fechanacimiento DATE NOT NULL,
rfc VARCHAR(50) NOT NULL,
pass VARCHAR(50) NOT NULL)

DROP TABLE permisos;
CREATE TABLE permisos(
fkusuario INT NOT NULL,
modulo INT NOT NULL,
lectura BOOL NOT NULL,
escritura BOOL NOT NULL,
actualizar BOOL NOT NULL,
eliminar BOOL NOT NULL,
FOREIGN KEY(fkusuario) REFERENCES usuarios(id),
PRIMARY KEY (fkusuario, modulo)); 

CREATE TABLE modulos(
id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL);


DROP PROCEDURE if EXISTS insertarproductos;
delimiter ;;
CREATE PROCEDURE insertarproductos(
IN _codigo INT, IN _nombre VARCHAR(50), IN _descripcion VARCHAR(100), IN _marca VARCHAR(50)) 
BEGIN   
   if _codigo < 0 then
      INSERT INTO productos VALUES(NULL, _nombre, _descripcion, _marca); 
   ELSE if _codigo > 0 then 
      UPDATE productos SET nombre = _nombre, descripcion = _descripcion, marca = _marca WHERE codigoBarras = _codigo; 
   END if; 
   END if; 
END;;
CALL insertarproductos(-1, 'llanta', 'es una llanta', 'michelin');
SELECT * FROM productos;

DROP PROCEDURE if EXISTS insertarherramientas;
delimiter ;;
CREATE PROCEDURE insertarherramientas(
IN _codigo INT, IN _nombre VARCHAR(50), IN _descripcion VARCHAR(100), IN _marca VARCHAR(50), IN _medida INT) 
BEGIN   
   if _codigo < 0 then
      INSERT INTO herramientas VALUES(NULL, _nombre, _descripcion, _marca, _medida); 
   ELSE if _codigo > 0 then 
      UPDATE herramientas SET nombre = _nombre, descripcion = _descripcion, marca = _marca, medida = _medida
		WHERE codigoBarras = _codigo; 
   END if; 
   END if; 
END;;
CALL insertarherramientas(-1, 'martillo', 'es un martillo', 'truper', 12);
SELECT * FROM herramientas;

DROP PROCEDURE if EXISTS insertarusuarios;
delimiter ;;
CREATE PROCEDURE insertarusuarios(
IN _id INT, IN _nombre VARCHAR(50), IN _apellidop VARCHAR(100), IN _apellidom VARCHAR(50), IN _fecha DATE, 
IN _rfc VARCHAR(50), IN _contraseña VARCHAR(50)) 
BEGIN   
   if _id = 0 then
      INSERT INTO usuarios VALUES(NULL, _nombre, _apellidop, _apellidom, _fecha, _rfc, _contraseña); 
   ELSE if _id != 0 then
      INSERT INTO usuarios VALUES(NULL, _nombre, _apellidop, _apellidom, _fecha, _rfc, _contraseña); 
   END if; 
   END if; 
END;;
CALL insertarusuarios(-1, 'Luis', 'lol', 'xd', '1995-03-25', '6huia', 'awa');
SELECT * FROM usuarios;

DROP PROCEDURE if EXISTS insertarpermisos;
delimiter ;;
CREATE PROCEDURE insertarpermisos(
IN _usuario INT, IN _modulo INT, IN _lectura BOOL, IN _escritura BOOL, IN _actualizar BOOL, IN _eliminar BOOL,
IN _opcion INT) 
BEGIN   
   if _opcion = 1 then
      INSERT INTO permisos VALUES(_usuario, _modulo, _lectura, _escritura, _actualizar, _eliminar); 
   ELSE if _opcion = 2 then
      UPDATE permisos SET usuario = _usuario, modulo = _modulo, lectura = _lectura, escritura = _escritura,
      actualizar = _actualizar, eliminar = _eliminar WHERE usuario = _usuario AND modulo = _modulo; 
   END if; 
   END if; 
END;;
CALL insertarpermisos(2, 1, TRUE, FALSE, TRUE, TRUE, 1);
SELECT * FROM permisos;

DROP PROCEDURE if EXISTS insertarmodulos;
delimiter ;;
CREATE PROCEDURE insertarmodulos(
IN _id INT, IN _nombre VARCHAR(50)) 
BEGIN   
   if _id < 0 then
      INSERT INTO modulos VALUES(NULL, _nombre); 
   ELSE if _id > 0 then
      UPDATE modulos SET nombre = _nombre WHERE id = _id; 
   END if; 
   END if; 
END;;
CALL insertarmodulos(-1, 'Empleados');
SELECT * FROM modulos;

DROP VIEW viewpermisos;
CREATE VIEW viewpermisos AS 
SELECT usuarios.nombre AS 'Usuario', modulos.nombre AS 'Modulo', lectura, escritura, actualizar, eliminar 
FROM permisos INNER JOIN usuarios ON usuarios.id = permisos.fkusuario 
INNER JOIN modulos ON modulos.id = permisos.fkusuario;  
SELECT * FROM viewpermisos;

DELETE FROM modulos WHERE id = 3;
DELETE FROM usuarios WHERE id = 3;
INSERT INTO usuarios VALUES(NULL, 'Alfred', 'q', 'w', '1995-03-23', 'rfsd4', 'qwe');
INSERT INTO usuarios VALUES(NULL, 'Anya', 'owo', 'uwu', '1995-01-29', '12wq1', 'juan');
INSERT INTO usuarios VALUES(NULL, 'Pepe', 'lol', 'xd', '1995-03-25', '6huia', 'awa');
INSERT INTO permisos VALUES(1, 1, TRUE, TRUE, TRUE, TRUE);
INSERT INTO permisos VALUES(1, 2, TRUE, FALSE, FALSE, TRUE);
INSERT INTO modulos VALUES(NULL, 'productos');
INSERT INTO modulos VALUES(NULL, 'herramientas');
SELECT * FROM usuarios;
SELECT * FROM permisos;
SELECT * FROM modulos;
SELECT * FROM productos;
SELECT * FROM herramientas;

DESCRIBE usuarios;
DESCRIBE permisos;
DESCRIBE productos;
DESCRIBE herramientas;

